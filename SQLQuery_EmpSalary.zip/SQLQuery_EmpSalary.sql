create database EmpSalary
use EmpSalary

create table Emp_details(id int primary key ,code varchar(50),name varchar(20),phoneno bigint,email varchar(50),address varchar(50))

--stored procedure

create procedure sp_insert(@id int,@code varchar(50),@name varchar(20),@phoneno bigint,@email varchar(50),@address varchar(50))
as
begin
insert into Emp_details values(@id,@code,@name,@phoneno,@email,@address)
end

create procedure sp_update(@id int,@code varchar(50),@name varchar(20),@phoneno bigint,@email varchar(50),@address varchar(50))
as
begin
update Emp_details set code=@code,name=@name,phoneno=@phoneno,email=@email,address=@address where id=@id
end

alter procedure sp_delete(@id int)--,@code varchar(50),@name varchar(20),@phoneno bigint,@email varchar(50),@address varchar(50))
as
begin
delete from Emp_details where id=@id
end

-------------------------------------
create table Emp_salary(s_id int,code varchar(50),salary money)

--stored procedure
create procedure sp1_insert(@s_id int,@code varchar(50),@salary money)
as
begin
insert into Emp_salary values(@s_id,@code,@salary)
end

create procedure sp1_update(@s_id int,@code varchar(50),@salary money)
as
begin
update Emp_salary set code=@code,salary=@salary where s_id=@s_id
end

alter procedure sp1_delete(@s_id int)
as
begin
delete from Emp_salary where s_id=@s_id
end

select *from Emp_details inner join Emp_salary on Emp_details.code=Emp_salary.code

---view---
create procedure es_view  ---just given inner join in procedure
as 
begin
select *from Emp_details inner join Emp_salary on Emp_details.code=Emp_salary.code
end

delete from Emp_details where id=1
delete from Emp_salary where s_id=11

truncate table Emp_details